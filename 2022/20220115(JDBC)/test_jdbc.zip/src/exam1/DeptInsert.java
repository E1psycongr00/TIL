package exam1;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class DeptInsert {

	public static void main(String[] args) {
		//1. 4가지 정보 설정
		String driver = "oracle.jdbc.driver.OracleDriver";
		String url = "jdbc:oracle:thin:@localhost:1521:xe";
		String userid = "SCOTT";
		String passwd = "TIGER";
		
		//2. 드라이버 로딩 ==> "oracle.jdbc.driver.OracleDriver" 객체생성하는 작업의미
		try {
			Class.forName(driver);
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
		
		Connection con = null;
		PreparedStatement pstmt = null;
		
		try {
			con = DriverManager.getConnection(url, userid, passwd);
			String sql = "insert into dept (deptno, dname, loc) values (?, ?, ?)";
			pstmt = con.prepareStatement(sql);
			pstmt.setInt(1, 99);
			pstmt.setString(2, "개발");
			pstmt.setNString(3, "서울");
			int num = pstmt.executeUpdate(); // 자동 커밋
			
			pstmt.setInt(1, 98);
			pstmt.setString(2, "개발");
			pstmt.setNString(3, "서울");
			int num = pstmt.executeUpdate();
			System.out.println("저장된 레코드 개수: " + num);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			//7. 자원반납 ==> 사용했던 객체의 역순으로 close한다.
			try {
				if(pstmt!=null)pstmt.close();
				if(con!=null)con.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		

	}

}
