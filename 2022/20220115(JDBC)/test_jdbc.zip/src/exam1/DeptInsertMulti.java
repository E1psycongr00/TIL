package exam1;

public class DeptInsertMulti {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
