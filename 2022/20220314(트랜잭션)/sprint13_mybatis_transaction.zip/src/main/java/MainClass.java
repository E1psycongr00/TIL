import java.util.List;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.GenericXmlApplicationContext;

import com.dto.DeptDTO;
import com.service.DeptService;

public class MainClass {

	public static void main(String[] args) {

		ApplicationContext ctx =
				new GenericXmlApplicationContext("classpath:com/config/dept.xml");
		
		DeptService service = ctx.getBean("deptService", DeptService.class);
		List<DeptDTO> list = service.selectAll();
		System.out.println(list);
		
		// 1. Spring은 auto commit
		// int num = service.insert(new DeptDTO(88, "IT", "부산"));
		
//		 int num2 = service.update(new DeptDTO(88, "AI", "서울"));
		
//		int num3 = service.delete(88);
		
		service.tx();
	}

}
